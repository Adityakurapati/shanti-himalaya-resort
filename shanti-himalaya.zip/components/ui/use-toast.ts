import { useToast, toast } from "@/hooks/use-toast";
import type { Tables } from "@/integrations/supabase/types";

export { useToast, toast };
