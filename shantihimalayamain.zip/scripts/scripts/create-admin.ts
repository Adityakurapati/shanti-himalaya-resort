import { createClient } from "@supabase/supabase-js";
import dotenv from "dotenv";
dotenv.config(); // load .env automatically

async function main() {
  const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL!;
  const SERVICE_ROLE = process.env.SUPABASE_SERVICE_ROLE_KEY!;

  if (!SUPABASE_URL || !SERVICE_ROLE) {
    console.error(
      "[v0] Missing NEXT_PUBLIC_SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY in Vars."
    );
    process.exit(1);
  }

  // ✅ Hardcoded email and password here
  const adminEmail = "admin@shantihimalaya.com";
  const adminPassword = "ShantiHimalaya$2025";

  const admin = createClient(SUPABASE_URL, SERVICE_ROLE);

  // 1) Create the Auth user
  const { data: created, error: createErr } = await admin.auth.admin.createUser(
    {
      email: adminEmail,
      password: adminPassword,
      email_confirm: true,
    }
  );

  if (
    createErr &&
    !String(createErr.message || "").includes("User already registered")
  ) {
    console.error("[v0] createUser error:", createErr.message);
    process.exit(1);
  }

  // 2) Get user ID (existing or newly created)
  const userId =
    created?.user?.id ||
    (
      await admin
        .from("user_roles")
        .select("user_id")
        .eq("role", "admin")
        .eq("approved", true)
        .limit(1)
    ).data?.[0]?.user_id ||
    (await admin.rpc("get_user_id_by_email", { _email: adminEmail }))?.data;

  // 3) Fallback: fetch directly from auth.users
  let finalUserId = userId;
  if (!finalUserId) {
    const { data: authUsers, error: authErr } = await admin
      .from("auth.users" as any)
      .select("id")
      .eq("email", adminEmail)
      .limit(1);

    if (authErr) {
      console.error(
        "[v0] Could not fetch user id from auth.users:",
        authErr.message
      );
      process.exit(1);
    }
    finalUserId = authUsers?.[0]?.id;
  }

  if (!finalUserId) {
    console.error("[v0] Could not resolve user id for:", adminEmail);
    process.exit(1);
  }

  // 4) Check if main_admin already exists
  const { data: existingMain } = await admin
    .from("user_roles")
    .select("id")
    .eq("role", "main_admin")
    .limit(1);

  const targetRole =
    existingMain && existingMain.length > 0 ? "admin" : "main_admin";

  // 5) Upsert the admin role
  const { error: roleErr } = await admin
    .from("user_roles")
    .upsert(
      { user_id: finalUserId, role: targetRole, approved: true },
      { onConflict: "user_id,role" }
    );

  if (roleErr) {
    console.error("[v0] upsert admin role error:", roleErr.message);
    process.exit(1);
  }

  console.log(`[v0] Admin ensured for ${adminEmail} (user_id=${finalUserId}).`);
}

main().catch((e) => {
  console.error("[v0] Unexpected error:", e);
  process.exit(1);
});
