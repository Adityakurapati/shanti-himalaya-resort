import * as AspectRatioPrimitive from "@radix-ui/react-aspect-ratio";
import type { Tables } from "@/integrations/supabase/types";

const AspectRatio = AspectRatioPrimitive.Root;

export { AspectRatio };
